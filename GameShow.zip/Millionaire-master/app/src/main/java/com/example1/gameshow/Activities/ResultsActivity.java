package com.example1.gameshow.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import com.example1.gameshow.R;


public class ResultsActivity extends AppCompatActivity implements View.OnClickListener {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        Intent intent;
        String score;
        boolean isQuizPerfect;
        ImageView imageView;
        TextView textViewMessage, textViewScore;
        Button buttonFinish;

        setContentView(R.layout.activity_results);

        intent = getIntent();
        score = intent.getStringExtra(QuizActivity.EXTRA_SCORE);
        isQuizPerfect = intent.getBooleanExtra(QuizActivity.EXTRA_IS_QUIZ_PERFECT, false);

        imageView = findViewById(R.id.image_view_results);
        textViewMessage = findViewById(R.id.text_view_results_message);
        textViewScore = findViewById(R.id.text_view_results_score);

        if (isQuizPerfect) {
            imageView.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_baseline_check_circle_24));
            textViewMessage.setText(getString(R.string.text_view_results_message_success));
        }

        else {
            imageView.setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_baseline_cancel_24));
            textViewMessage.setText(getString(R.string.text_view_results_message_failed));
        }

        textViewScore.setText(getString(R.string.text_view_results_score, score));

        buttonFinish = findViewById(R.id.button_finish);
        buttonFinish.setOnClickListener(this);
    }


    @Override
    public void onBackPressed() {
    }


    @Override
    public void onClick(View v) {
        Intent intent = new Intent(this, WelcomeActivity.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }
}
