package com.example1.gameshow.Activities;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.Toast;
import android.widget.Switch;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.example1.gameshow.Models.Question;
import com.example1.gameshow.Models.Quiz;
import com.example1.gameshow.R;

import java.util.ArrayList;


public class QuizActivity extends AppCompatActivity implements View.OnClickListener {

    // Intent extra constants.
    public static String EXTRA_SCORE = "score";
    public static String EXTRA_IS_QUIZ_PERFECT = "is_quiz_perfect";

    // Activity objects.
    private TextView textViewQuizPosition, textViewScore, textViewQuestion;
    private RadioGroup radioGroupOptions;
    private RadioButton radioButtonOption1, radioButtonOption2, radioButtonOption3, radioButtonOption4;
    private Quiz quiz;


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Inflate quiz layout.
        setContentView(R.layout.activity_quiz);

        // Setup view objects from quiz layout.
        textViewQuizPosition = findViewById(R.id.text_view_quiz_position);
        textViewScore = findViewById(R.id.text_view_score);
        textViewQuestion = findViewById(R.id.text_view_question);
        radioGroupOptions = findViewById(R.id.radio_group_options);
        radioButtonOption1 = findViewById(R.id.radio_option_1);
        radioButtonOption2 = findViewById(R.id.radio_option_2);
        radioButtonOption3 = findViewById(R.id.radio_option_3);
        radioButtonOption4 = findViewById(R.id.radio_option_4);

        // Setup next button click listener.
        Button buttonNext = findViewById(R.id.button_next);
        buttonNext.setOnClickListener(this);

        // Setup quiz object.
        quiz = new Quiz(getSampleQuestions());

        // Populate the layout with the first question.
        populateLayoutWithCurrentQuestion();
    }


    @Override
    public void onBackPressed() {
    }


    @Override
    public void onClick(View v) {
        //AlertDialog alertDialog = new AlertDialog.Builder(QuizActivity.this);
        // Grade the current question.
        boolean isCurrentQuestionCorrect = quiz.gradeCurrentQuestion(
                radioButtonOption1.isChecked(),
                radioButtonOption2.isChecked(),
                radioButtonOption3.isChecked(),
                radioButtonOption4.isChecked()
        );

        // If the quiz is finished or the question was answered incorrectly, start the results activity.
        if (quiz.isQuizFinished() || !isCurrentQuestionCorrect) {
            Intent intent = new Intent(QuizActivity.this, ResultsActivity.class);
            intent.putExtra(EXTRA_SCORE, quiz.getScore());
            intent.putExtra(EXTRA_IS_QUIZ_PERFECT, quiz.isQuizPerfect());
            startActivity(intent);
        }

        // Otherwise, populate the layout with the new current question.
        else {
            populateLayoutWithCurrentQuestion();
        }
    }


    private ArrayList<Question> getSampleQuestions() {

        ArrayList<Question> questions = new ArrayList<>();

        questions.add(new Question(
                "How many time zones are there in America?",
                "4",
                "6",
                "5",
                "7",
                false,
                true,
                false,
                false
        ));
        questions.add(new Question(
                "What country has the most islands in the world?",
                "United States",
                "Indonesia",
                "Sweden",
                "Philippines",
                false,
                false,
                true,
                false
        ));
        questions.add(new Question(
                "When did the Revolutionary War start?",
                "1775",
                "1776",
                "1750",
                "1738",
                true,
                false,
                false,
                false
        ));
        questions.add(new Question(
                "What day is it?",
                "today",
                "sunday",
                "saturday",
                "monday",
                true,
                false,
                false,
                false
        ));
        questions.add(new Question(
                "Where was the last Olympic Games held?",
                "Qatar",
                "Norway",
                "Sochi",
                "Beijing",
                false,
                false,
                false,
                true
        ));
        questions.add(new Question(
                "When was Montclair founded?",
                "1908",
                "1928",
                "2012",
                "1905",
                true,
                false,
                false,
                false
        ));
        questions.add(new Question(
                "What’s the national flower of the US?",
                "Ivy",
                "Lavender",
                "Rose",
                "Cherry blossom",
                false,
                false,
                true,
                false
        ));
        questions.add(new Question(
                "What’s the smallest state in the US?",
                "Maine",
                "Rhode Island",
                "Hawaii",
                "Delaware",
                false,
                true,
                false,
                false
        ));
        questions.add(new Question(
                "What movie franchise has the most sequels?",
                "Batman?",
                "Godzilla",
                "Spider-Man",
                "Star Wars",
                false,
                true,
                false,
                false
        ));
        questions.add(new Question(
                "Which country invented the Internet?",
                "USA",
                "France",
                "China",
                "Germany",
                true,
                false,
                false,
                false
        ));
        questions.add(new Question(
                "What class is this?",
                "451",
                "351",
                "460",
                "400",
                true,
                false,
                false,
                false
        ));
        questions.add(new Question(
                "Which football team won the last Super Bowl?",
                "Bengals",
                "Rams",
                "Giants",
                "Yankees",
                false,
                true,
                false,
                false
        ));
        questions.add(new Question(
                "Will I get a 100?",
                "nope",
                "no",
                "yes",
                "maybe",
                false,
                false,
                false,
                true
        ));
        questions.add(new Question(
                "How many stripes are there on the US flag?",
                "11",
                "13",
                "50",
                "3",
                false,
                true,
                false,
                false
        ));
        questions.add(new Question(
                "What’s the capital of NJ?",
                "Hackensack",
                "Trenton",
                "Edison",
                "Lodi",
                false,
                true,
                false,
                false
        ));
        questions.add(new Question(
                "Name the Montclair mascot?",
                "Rocky the Red Hawk",
                "Randy the Red Hawk.",
                "Ronald the Red Hawk",
                "Hawky",
                true,
                false,
                false,
                false
        ));

        return questions;
    }


    private void populateLayoutWithCurrentQuestion() {

        // Get the current question from the quiz object.
        Question currentQuestion = quiz.getCurrentQuestion();

        // Populate the layout with attributes of the current question and state of the quiz.
        textViewQuizPosition.setText(getString(R.string.action_bar_label_quiz, quiz.getNumberCurrentQuestion(), quiz.getNumberTotalQuestions()));
        textViewScore.setText(getString(R.string.action_bar_label_score, quiz.getScore()));
        textViewQuestion.setText(currentQuestion.getQuestion());
        radioGroupOptions.clearCheck();
        radioButtonOption1.setText(currentQuestion.getOption1());
        radioButtonOption2.setText(currentQuestion.getOption2());
        radioButtonOption3.setText(currentQuestion.getOption3());
        radioButtonOption4.setText(currentQuestion.getOption4());
    }



}
